# Vshare 📡

A simple tool to share any file over LAN using a QR code and a local web server.

## Install

```bash
pip install vshare
